if mods["Krastorio2"] then

data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].collision_box = {{-2.4,-2.4},{2.4,2.4}}
data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].selection_box = {{-2.5,-2.5},{2.5,2.5}}
data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].input_fluid_box =
		{
			production_type = "input-output",
			pipe_picture = assembler2pipepictures(),
			pipe_covers = pipecoverspictures(),
			base_area = 1,
			height = 2,
			base_level = -1,
			pipe_connections =
			{
				{ position = {-3, 0} },
				{ position = {3, 0} },
				{ position = {0, 3} }
			}
		}
data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].mining_speed = 4.5
data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].energy_usage = "675kW"
data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].resource_searching_radius = 5.49
data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].vector_to_place_result = {0, -2.85}
data.raw["mining-drill"]["kr-electric-mining-drill-mk2"].module_specification ={module_slots = 6}

data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].collision_box = {{-2.4,-2.4},{2.4,2.4}}
data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].selection_box = {{-2.5,-2.5},{2.5,2.5}}
data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].input_fluid_box =
		{
			production_type = "input-output",
			pipe_picture = assembler2pipepictures(),
			pipe_covers = pipecoverspictures(),
			base_area = 1,
			height = 2,
			base_level = -1,
			pipe_connections =
			{
				{ position = {-3, 0} },
				{ position = {3, 0} },
				{ position = {0, 3} }
			}
		}
data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].mining_speed = 5
data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].energy_usage = "725kW"
data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].resource_searching_radius = 5.49
data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].vector_to_place_result = {0, -2.85}
data.raw["mining-drill"]["kr-electric-mining-drill-mk3"].module_specification ={module_slots = 6}

data.raw["mining-drill"]["advanced-electric-mining-drill"].enabled = false

data:extend(
{
  {
    type = "recipe",
    name = "steam-copper-plate",
    category = "steam-smelting",
    energy_required = 3.2,
	enabled = false,
    ingredients = {{ "copper-ore", 200}},
    result = "copper-plate",
    result_count = 40
  },
  {
    type = "recipe",
    name = "steam-iron-plate",
    category = "steam-smelting",
    energy_required = 3.2,
	enabled = false,
    ingredients = {{"iron-ore", 200}},
    result = "iron-plate",
    result_count = 40
  },
  {
    type = "recipe",
    name = "steam-stone-brick",
    category = "steam-smelting",
    energy_required = 3.2,
    enabled = false,
    ingredients = {{"stone", 200}},
    result = "stone-brick",
    result_count = 40
  },
  {
    type = "recipe",
    name = "steam-rare-metals",
    category = "steam-smelting",
    energy_required = 3.2,
    enabled = false,
    ingredients = {{"raw-rare-metals", 200}},
    result = "rare-metals",
    result_count = 40
  },
  
  
  {
    type = "recipe",
    name = "steam-enriched-copper-plate",
    category = "steam-smelting",
    energy_required = 3.2,
	enabled = false,
    ingredients = {{ "enriched-copper", 200}},
    result = "copper-plate",
    result_count = 200
  },
  {
    type = "recipe",
    name = "steam-enriched-iron-plate",
    category = "steam-smelting",
    energy_required = 3.2,
	enabled = false,
    ingredients = {{"enriched-iron", 200}},
    result = "iron-plate",
    result_count = 200
  },
  {
    type = "recipe",
    name = "steam-enriched-rare-metals",
    category = "steam-smelting",
    energy_required = 3.2,
    enabled = false,
    ingredients = {{"enriched-rare-metals", 200}},
    result = "rare-metals",
    result_count = 200
  },
})

data:extend(
{
  {
	type = "technology",
    name = "advanced-mining",
    icon_size = 256, icon_mipmaps = 4,
    icon = "__base__/graphics/technology/mining-productivity.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-electric-mining-drill"
      }
    },
    prerequisites = {"advanced-electronics", "kr-electric-mining-drill"},
    unit =
    {
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1}
      },
      time = 30,
      count = 250
    },
    order = "e-p-b-c"
  },
  {
	type = "technology",
	name = "kr-electric-mining-drill-mk2",
	mod = "Krastorio2",
	icon = kr_technologies_icons_path .. "electric-mining-drill-mk2.png",
	icon_size = 256, 
	icon_mipmaps = 4,
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "kr-electric-mining-drill-mk2"
		}
	},
	prerequisites = {"advanced-mining", "engine"},
	unit =
	{
		count = 300,
		ingredients = 
		{
			{"automation-science-pack", 1},
			{"logistic-science-pack", 1},
			{"chemical-science-pack", 1}
		},
		time = 45
		}	
  },
  {
	type = "recipe",
	name = "kr-electric-mining-drill-mk2",
	energy_required = 5,
	enabled = false,
	ingredients =
	{
		{"advanced-electric-mining-drill", 1},
		{"steel-gear-wheel", 5},
		{"rare-metals", 4}
	},
	result = "kr-electric-mining-drill-mk2"
  },
  {
    type = "technology",
    name = "cat-basic-fluid-handling",
    icon_size = 256, icon_mipmaps = 4,
    icon = "__base__/graphics/technology/fluid-handling.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "copper-storage-tank"
      },
	  {
	    type = "unlock-recipe",
		recipe = "steam-furnace"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "boiler"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "steam-iron-plate"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "steam-copper-plate"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "steam-stone-brick"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "steam-rare-metals"
	  }
    },
    prerequisites = {"kr-basic-fluid-handling"},
    unit =
    {
      ingredients =
      {
        {"automation-science-pack", 1}
      },
      time = 15,
      count = 50
    },
    order = "e-p-b-c"
  },
	{
		type = "technology",
		name = "kr-enriched-ores",
		mod = "Krastorio2",
		icon = kr_technologies_icons_path .. "enriched-ores.png",
		icon_size = 256, 
		icon_mipmaps = 4,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "enriched-iron"
			},
			{
				type = "unlock-recipe",
				recipe = "enriched-copper"
			},
			{
				type = "unlock-recipe",
				recipe = "enriched-rare-metals"
			},			
			{
				type = "unlock-recipe",
				recipe = "enriched-iron-plate"
			},
			{
				type = "unlock-recipe",
				recipe = "enriched-copper-plate"
			},
			{
				type = "unlock-recipe",
				recipe = "rare-metals-2"
			},			
			{
				type = "unlock-recipe",
				recipe = "dirty-water-filtration-1"
			},
			{
				type = "unlock-recipe",
				recipe = "dirty-water-filtration-2"
			},
			{
				type = "unlock-recipe",
				recipe = "dirty-water-filtration-3"
			},
			{
				type = "unlock-recipe",
				recipe = "steam-enriched-copper-plate"
			},
			{
				type = "unlock-recipe",
				recipe = "steam-enriched-iron-plate"
			},
			{
				type = "unlock-recipe",
				recipe = "steam-enriched-rare-metals"
			},
		},
		prerequisites = {"kr-advanced-chemistry"},
		unit =
		{
			count = 275,
			ingredients = 
			{
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1},
				{"chemical-science-pack", 1}
			},
			time = 60
		}
    },
})
end