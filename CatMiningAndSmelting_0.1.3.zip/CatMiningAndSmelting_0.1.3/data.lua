--data.lua

require("prototypes.aemd")
require("prototypes.emd")
require("prototypes.bmd")
require("prototypes.recipe")
require("prototypes.item")
require("prototypes.technology")
require("prototypes.smelters")
require("prototypes.steam-furnace")
require("prototypes.recipe-category")
require("prototypes.fluid-handling")