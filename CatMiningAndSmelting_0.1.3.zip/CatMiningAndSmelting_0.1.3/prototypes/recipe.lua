data:extend({
 {
  type = "recipe",
  name = "burner-mining-drill",
  normal = 
  {
    energy_required = 2,
    ingredients = 
	{
      {"stone-brick", 15},
      {"iron-gear-wheel", 10}
    },
	result = "burner-mining-drill"
  },
  expensive = 
  {
    energy_required = 2,
    ingredients =
	{
      {"stone-brick", 30},
      {"iron-gear-wheel", 20}
    },
	result = "burner-mining-drill"
  }
 },
  
 {
  type = "recipe",
  name = "electric-mining-drill",
  normal = 
  {
    energy_required = 2,
    ingredients = 
	{
	  {"burner-mining-drill", 1},
      {"electronic-circuit", 10},
      {"iron-plate", 25},
      {"iron-gear-wheel", 15}
    },
	result = "electric-mining-drill"
  },
  expensive = {
    energy_required = 2,
    ingredients = 
	{
	  {"burner-mining-drill", 2},
      {"electronic-circuit", 20},
      {"iron-plate", 50},
      {"iron-gear-wheel", 30}
    },
	result = "electric-mining-drill"
  }
 },
 
 {
  type = "recipe",
  name = "advanced-electric-mining-drill",
  enabled = false,
  energy_required = 2,
  ingredients = 
  {
	{"electric-mining-drill", 1},
    {"advanced-circuit", 15},
    {"steel-plate", 30},
    {"iron-gear-wheel", 40}
  },
  result = "advanced-electric-mining-drill"

 },
  {
  type = "recipe",
  name = "steam-furnace",
  enabled = false,
  energy_required = 2,
  ingredients = 
	{
	  {"stone-furnace", 4},
      {"copper-plate", 16},
      {"pipe", 4}
    },
  result = "steam-furnace"
 },
  {
  type = "recipe",
  name = "advanced-steam-furnace",
  enabled = false,
  energy_required = 2,
  ingredients = 
	{
	  {"steam-furnace", 4},
      {"steel-plate", 20},
      {"pipe", 8}
    },
  result = "advanced-steam-furnace"
 },
  {
    type = "recipe",
    name = "steam-copper-plate",
    category = "steam-smelting",
    energy_required = 3.2,
	enabled = false,
    ingredients = {{ "copper-ore", 50}},
    result = "copper-plate",
    result_count = 50
  },
  {
    type = "recipe",
    name = "steam-iron-plate",
    category = "steam-smelting",
    energy_required = 3.2,
	enabled = false,
    ingredients = {{"iron-ore", 50}},
    result = "iron-plate",
    result_count = 50
  },
  {
    type = "recipe",
    name = "steam-stone-brick",
    category = "steam-smelting",
    energy_required = 3.2,
    enabled = false,
    ingredients = {{"stone", 50}},
    result = "stone-brick",
    result_count = 50
  },
  {
    type = "recipe",
	name = "copper-storage-tank",
	enabled = false,
	energy_required = 1,
	ingredients =
	  {
	    {"copper-plate", 16},
		{"pipe", 4}
	  },
	result = "copper-storage-tank"
  }
})