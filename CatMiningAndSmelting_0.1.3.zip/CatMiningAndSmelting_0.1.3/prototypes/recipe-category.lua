data:extend(
{
  {
    type = "recipe-category",
    name = "steam-smelting"
  }
})