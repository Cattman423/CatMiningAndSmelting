 data:extend (
{
 {
    type = "item",
    name = "advanced-electric-mining-drill",
    icon = "__base__/graphics/icons/electric-mining-drill.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "extraction-machine",
    order = "a[items]-c[electric-mining-drill]",
    place_result = "advanced-electric-mining-drill",
    stack_size = 50
  },
 {
    type = "item",
    name = "steam-furnace",
    icon = "__base__/graphics/icons/boiler.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "smelting-machine",
    order = "d[items]-d[steam-furnace]",
    place_result = "steam-furnace",
    stack_size = 50
  },
 {
    type = "item",
    name = "advanced-steam-furnace",
    icon = "__base__/graphics/icons/boiler.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "smelting-machine",
    order = "d[items]-d[advanced-steam-furnace]",
    place_result = "advanced-steam-furnace",
    stack_size = 50
  },
  {
    type = "item",
    name = "steam-iron-plate",
    icon = "__base__/graphics/icons/iron-plate.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "raw-material",
    order = "b[iron-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "steam-copper-plate",
    icon = "__base__/graphics/icons/copper-plate.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "raw-material",
    order = "c[copper-plate]",
    stack_size = 100
  },
  {
    type = "item",
    name = "steam-stone-brick",
    icon = "__base__/graphics/icons/stone-brick.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "terrain",
    order = "a[stone-brick]",
    stack_size = 100,
    place_as_tile =
    {
      result = "stone-path",
      condition_size = 1,
      condition = { "water-tile" }
    }
  },
  {
    type = "item",
    name = "copper-storage-tank",
    icon = "__base__/graphics/icons/storage-tank.png",
    icon_size = 64, icon_mipmaps = 4,
    subgroup = "storage",
    order = "b[fluid]-b[storage-tank]",
    place_result = "copper-storage-tank",
    stack_size = 50
  },
})