data:extend(
{
  {
    type = "technology",
    name = "advanced-mining",
    icon_size = 256, icon_mipmaps = 4,
    icon = "__base__/graphics/technology/mining-productivity.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "advanced-electric-mining-drill"
      }
    },
    prerequisites = {"advanced-electronics"},
    unit =
    {
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1}
      },
      time = 30,
      count = 250
    },
    order = "e-p-b-c"
  },
  {
    type = "technology",
    name = "cat-basic-fluid-handling",
    icon_size = 256, icon_mipmaps = 4,
    icon = "__base__/graphics/technology/fluid-handling.png",
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "copper-storage-tank"
      },
	  {
	    type = "unlock-recipe",
		recipe = "steam-furnace"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "steam-iron-plate"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "steam-copper-plate"
	  },
	  {
	    type = "unlock-recipe",
		recipe = "steam-stone-brick"
	  },
    },
    prerequisites = {},
    unit =
    {
      ingredients =
      {
        {"automation-science-pack", 1}
      },
      time = 15,
      count = 50
    },
    order = "e-p-b-c"
  },
  {
    type = "technology",
    name = "fluid-handling",
    icon_size = 256, icon_mipmaps = 4,
    icon = "__base__/graphics/technology/fluid-handling.png",
    prerequisites = {"automation-2", "engine", "basic-fluid-handling", "advanced-material-processing"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "storage-tank"
      },
      {
        type = "unlock-recipe",
        recipe = "pump"
      },
      {
        type = "unlock-recipe",
        recipe = "advanced-steam-furnace"
      },
      {
        type = "unlock-recipe",
        recipe = "empty-barrel"
      },
    },
    unit =
    {
      count = 50,
      ingredients = {{"automation-science-pack", 1}, {"logistic-science-pack", 1}},
      time = 15
    },
    order = "d-a-a"
  },
})