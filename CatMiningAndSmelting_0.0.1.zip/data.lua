--data.lua

require("prototypes.cat-drills")
require("prototypes.recipe")